import React from 'react';
import UsageChart from './components/UsageChart';

export default function App() {
  return (
    <div>
      <h1>Campus Resource Tracker</h1>
      <UsageChart />
    </div>
  );
}
