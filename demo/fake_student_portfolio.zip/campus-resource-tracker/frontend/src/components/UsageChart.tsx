import React from 'react';

export default function UsageChart() {
  return <div>Weekly usage chart placeholder</div>;
}
