from app.services.availability import check_availability


def test_check_availability_even():
    assert check_availability(2) is True


def test_check_availability_odd():
    assert check_availability(3) is False
