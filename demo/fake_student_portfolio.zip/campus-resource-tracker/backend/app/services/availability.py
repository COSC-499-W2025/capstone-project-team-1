from datetime import datetime, timedelta

_CACHE = {}


def check_availability(space_id: int) -> bool:
    now = datetime.utcnow()
    cached = _CACHE.get(space_id)
    if cached and cached['expires'] > now:
        return cached['value']
    value = space_id % 2 == 0
    _CACHE[space_id] = {'value': value, 'expires': now + timedelta(minutes=5)}
    return value
