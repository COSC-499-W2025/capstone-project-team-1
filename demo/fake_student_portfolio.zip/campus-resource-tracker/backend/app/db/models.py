from sqlalchemy import Column, Integer, String
from sqlalchemy.orm import declarative_base

Base = declarative_base()

class Space(Base):
    __tablename__ = 'spaces'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
