from fastapi import APIRouter
from ..services.availability import check_availability

router = APIRouter()

@router.get('/')
def list_spaces():
    return {'spaces': ['Lab A', 'Lab B']}

@router.get('/{space_id}')
def get_space(space_id: int):
    return {'space_id': space_id, 'available': check_availability(space_id)}
