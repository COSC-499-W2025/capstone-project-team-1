from fastapi import FastAPI
from .routes import spaces

app = FastAPI()
app.include_router(spaces.router, prefix='/spaces')
