#include "kernel.h"

void boot_main() {
    // initialize basic systems
}
