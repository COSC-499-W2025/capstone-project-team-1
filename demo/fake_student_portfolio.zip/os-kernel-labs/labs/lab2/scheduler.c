#include "kernel.h"

typedef struct {
    int pid;
    int runtime;
} task_t;

static task_t tasks[4];

void schedule() {
    int best = 0;
    for (int i = 1; i < 4; i++) {
        if (tasks[i].runtime < tasks[best].runtime) {
            best = i;
        }
    }
    tasks[best].runtime++;
}
