package tests;

import graph.ShortestPath;
import java.util.*;

public class GraphTest {
    public static void main(String[] args) {
        Map<Integer, List<int[]>> graph = new HashMap<>();
        graph.put(1, List.of(new int[]{2, 5}, new int[]{3, 2}));
        System.out.println(ShortestPath.dijkstra(graph, 1));
    }
}
