package sort;

public class QuickSort {
    public static void sort(int[] arr, int low, int high) {
        if (low >= high) return;
        int pivot = arr[high];
        int i = low;
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                int tmp = arr[i];
                arr[i] = arr[j];
                arr[j] = tmp;
                i++;
            }
        }
        int tmp = arr[i];
        arr[i] = arr[high];
        arr[high] = tmp;
        sort(arr, low, i - 1);
        sort(arr, i + 1, high);
    }
}
