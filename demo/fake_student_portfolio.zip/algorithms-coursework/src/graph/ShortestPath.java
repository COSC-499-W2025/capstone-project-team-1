package graph;

import java.util.*;

public class ShortestPath {
    public static Map<Integer, Integer> dijkstra(Map<Integer, List<int[]>> graph, int start) {
        Map<Integer, Integer> dist = new HashMap<>();
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        pq.add(new int[]{start, 0});
        dist.put(start, 0);
        while (!pq.isEmpty()) {
            int[] curr = pq.poll();
            int node = curr[0];
            int cost = curr[1];
            if (cost > dist.get(node)) continue;
            for (int[] edge : graph.getOrDefault(node, List.of())) {
                int next = edge[0];
                int newCost = cost + edge[1];
                if (!dist.containsKey(next) || newCost < dist.get(next)) {
                    dist.put(next, newCost);
                    pq.add(new int[]{next, newCost});
                }
            }
        }
        return dist;
    }
}
