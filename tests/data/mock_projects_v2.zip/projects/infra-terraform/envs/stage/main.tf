terraform {
  required_version = ">= 1.5.0"
  backend "local" {}
}

provider "aws" {
  region = "us-west-2"
}

locals {
  cost_center = "student-stage"
}

module "network" {
  source      = "../modules/network"
  vpc_cidr    = "10.2.0.0/16"
  cost_center = local.cost_center
}

module "app" {
  source         = "../modules/app"
  app_name       = "stage-portfolio"
  subnet_ids     = module.network.subnet_ids
  logging_bucket = "stage-logs"
  environment    = "stage"
}

module "logging" {
  source         = "../modules/app"
  app_name       = "logs-stage"
  subnet_ids     = module.network.subnet_ids
  logging_bucket = "central-logs-stage"
  environment    = "stage"
}

output "service_url" { value = module.app.service_url }
output "logging_bucket" { value = module.app.logging_bucket }
output "cost_center" { value = local.cost_center }
