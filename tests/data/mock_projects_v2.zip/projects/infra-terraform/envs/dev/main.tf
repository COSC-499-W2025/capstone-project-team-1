terraform {
  required_version = ">= 1.5.0"
  backend "local" {}
}

provider "aws" {
  region = "us-west-2"
}

locals {
  cost_center = "student-lab"
}

module "network" {
  source    = "../modules/network"
  vpc_cidr  = "10.1.0.0/16"
  cost_center = local.cost_center
}

module "app" {
  source         = "../modules/app"
  app_name       = "dev-portfolio"
  subnet_ids     = module.network.subnet_ids
  logging_bucket = "dev-logs"
  environment    = "dev"
}

module "logging" {
  source         = "../modules/app"
  app_name       = "logs"
  subnet_ids     = module.network.subnet_ids
  logging_bucket = "central-logs"
  environment    = "dev"
}

output "service_url" { value = module.app.service_url }
output "logging_bucket" { value = module.app.logging_bucket }
output "cost_center" { value = local.cost_center }
# todo: wire remote backend for team runs
