app_name = "dev-portfolio"
logging_bucket = "dev-logs"
