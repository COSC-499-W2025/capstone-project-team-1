variable "vpc_cidr" { default = "10.0.0.0/16" }
output "vpc_id" { value = "vpc-123456" }
output "subnet_ids" { value = ["subnet-a", "subnet-b"] }
variable "tags" { type = map(string); default = { env = "dev" } }
variable "enable_flow_logs" { type = bool, default = true }
variable "cost_center" { type = string, default = "student" }
resource "aws_security_group" "app" { name = "app-sg" }
