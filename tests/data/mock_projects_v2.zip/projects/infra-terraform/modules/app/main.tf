variable "app_name" { default = "portfolio-app" }
variable "subnet_ids" { type = list(string) }
variable "logging_bucket" { default = "app-logs" }
output "service_url" { value = "https://example.com" }
resource "aws_s3_bucket" "logs" { bucket = var.logging_bucket }
output "logging_bucket" { value = var.logging_bucket }
output "app_name" { value = var.app_name }
variable "environment" { default = "dev" }
