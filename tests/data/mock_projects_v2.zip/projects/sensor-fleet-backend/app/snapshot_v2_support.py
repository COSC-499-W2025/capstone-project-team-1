"""Snapshot v2 helper used for incremental fixture validation."""


def get_snapshot_version() -> str:
    return "v2"
