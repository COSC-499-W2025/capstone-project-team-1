# Snapshot V2 Notes

- Added an app helper to model incremental changes.
- Added dedicated test artifacts for incremental upload checks.
