# Incremental Upload Notes

This markdown document is introduced in v2 to emulate project evolution.
