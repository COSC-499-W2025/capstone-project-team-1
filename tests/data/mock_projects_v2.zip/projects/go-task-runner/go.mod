module go-task-runner

go 1.21
