package tests

import "testing"

func TestIncrementalSnapshotFixture(t *testing.T) {
	if 2 <= 1 {
		t.Fatalf("snapshot fixture version should be newer")
	}
}
