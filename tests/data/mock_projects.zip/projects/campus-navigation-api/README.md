# Campus Navigation API

TypeScript Express API for campus pathfinding and schedule-aware routing. Provides health, building listings, and shortest-path endpoints.

## Scripts
```bash
npm install
npm run build
npm start  # serves compiled dist
npm test   # type-checks and lints
```
- Added schedule endpoint with busy buildings
# Deployment\n- Deployable via 
> campus-navigation-api@0.1.0 build
> tsc

src/index.ts(1,21): error TS2307: Cannot find module 'express' or its corresponding type declarations.
src/index.ts(8,21): error TS7006: Parameter '_req' implicitly has an 'any' type.
src/index.ts(8,27): error TS7006: Parameter 'res' implicitly has an 'any' type.
src/index.ts(10,24): error TS7006: Parameter '_req' implicitly has an 'any' type.
src/index.ts(10,30): error TS7006: Parameter 'res' implicitly has an 'any' type.
src/index.ts(12,21): error TS7006: Parameter 'req' implicitly has an 'any' type.
src/index.ts(12,26): error TS7006: Parameter 'res' implicitly has an 'any' type.
src/index.ts(20,14): error TS2580: Cannot find name 'process'. Do you need to install type definitions for node? Try `npm i --save-dev @types/node`.
src/index.ts(21,5): error TS2580: Cannot find name 'process'. Do you need to install type definitions for node? Try `npm i --save-dev @types/node`.
src/index.ts(26,10): error TS7006: Parameter '_req' implicitly has an 'any' type.
src/index.ts(26,16): error TS7006: Parameter '_res' implicitly has an 'any' type.
src/index.ts(26,22): error TS7006: Parameter 'next' implicitly has an 'any' type.
src/index.ts(27,25): error TS7006: Parameter 'req' implicitly has an 'any' type.
src/index.ts(27,30): error TS7006: Parameter 'res' implicitly has an 'any' type.
src/index.ts(28,27): error TS2580: Cannot find name 'process'. Do you need to install type definitions for node? Try `npm i --save-dev @types/node`.
src/index.ts(29,23): error TS7006: Parameter '_req' implicitly has an 'any' type.
src/index.ts(29,29): error TS7006: Parameter 'res' implicitly has an 'any' type. -> upload dist to Node server.
- Added params route and single building lookup.
- [ ] Add weighted edges for elevators
