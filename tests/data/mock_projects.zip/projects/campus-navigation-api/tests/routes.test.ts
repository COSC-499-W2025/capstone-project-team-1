import { shortestPath } from '../src/graph.js';
import { campusGraph } from '../src/data.js';

const path = shortestPath(campusGraph, 'CS', 'GYM');
if (!path.length) throw new Error('Expected path from CS to GYM');
console.log('routes.test.ts: ok');
const fallback = shortestPath(campusGraph, 'CS', 'ENG'); if (!fallback.length) throw new Error('fallback path missing');
const reachable = isReachable(campusGraph, 'CS', 'GYM'); if (!reachable) throw new Error('graph should be connected');
if (shortestPath(campusGraph, 'LIB', 'ENG').length === 0) throw new Error('graph disconnected');
