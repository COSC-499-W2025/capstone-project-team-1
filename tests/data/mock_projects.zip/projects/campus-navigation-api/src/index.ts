import express from 'express';
import { campusGraph, buildings } from './data.js';
import { shortestPath } from './graph.js';

const app = express();
app.use(express.json());

app.get('/health', (_req, res) => res.json({ ok: true }));

app.get('/buildings', (_req, res) => res.json(buildings));

app.post('/route', (req, res) => {
  const { start, goal } = req.body;
  if (!start || !goal) return res.status(400).json({ error: 'start and goal required' });
  const path = shortestPath(campusGraph, start, goal);
  if (!path.length) return res.status(404).json({ error: 'no route found' });
  res.json({ path });
});

const port = process.env.PORT || 3000;
if (process.env.NODE_ENV !== 'test') {
  app.listen(port, () => console.log(`Campus nav API on :${port}`));
}

export default app;
app.use((_req, _res, next) => { /* request logging stub */ next(); });
app.post('/buildings', (req, res) => { const { id, name } = req.body; if (!id || !name) return res.status(400).json({ error: 'id and name required' }); buildings[id] = { name, facilities: [] }; res.status(201).json(buildings[id]); });
const [, , start, goal] = process.argv; if (start && goal) { console.log(JSON.stringify(shortestPath(campusGraph, start, goal))); }
app.get('/schedule', (_req, res) => res.json({ semester: 'Fall', busy: ['CS', 'ENG'] }));
app.get('/status', (_req, res) => res.json({ version: '0.1.0' }));
app.use((err, _req, res, _next) => { console.error(err); res.status(500).json({ error: 'server error' }); });
app.get('/buildings/:id', (req, res) => { const b = buildings[req.params.id]; if (!b) return res.status(404).json({ error: 'not found' }); res.json(b); });
app.get('/route/:start/:goal', (req, res)=>{ const path = shortestPath(campusGraph, req.params.start, req.params.goal); res.json({ path }); });
app.get('/facilities/:facility', (req, res)=>{ const ids = Object.entries(buildings).filter(([_id, b])=> b.facilities.includes(req.params.facility)).map(([id])=>id); res.json({ ids }); });
app.post('/closures', (req, res)=>{ const { id } = req.body; closures.add(id); res.json({ blocked:[...closures]}); });
app.use((req,_res,next)=>{ req.query = req.query || {}; next(); });
const prefer = req.query.prefer as string | undefined; if (prefer === 'quiet') { path.push('LIB'); }
