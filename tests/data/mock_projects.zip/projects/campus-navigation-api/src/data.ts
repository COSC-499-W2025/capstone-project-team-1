import { Graph } from './graph.js';

export const buildings: Record<string, { name: string; facilities: string[] }> = {
  CS: { name: 'Computer Science', facilities: ['labs', 'study'] },
  LIB: { name: 'Library', facilities: ['study', 'quiet'] },
  ENG: { name: 'Engineering', facilities: ['maker', 'labs'] },
  GYM: { name: 'Gym', facilities: ['fitness'] },
};

export const campusGraph: Graph = {
  CS: ['LIB', 'ENG'],
  LIB: ['CS', 'GYM'],
  ENG: ['CS', 'GYM'],
  GYM: ['LIB', 'ENG']
};
export function addBuilding(id: string, name: string) { buildings[id] = { name, facilities: [] }; }
export function attachFacility(id: string, facility: string) { if (!buildings[id]) return false; buildings[id].facilities.push(facility); return true; }
export const closures = new Set<string>();
