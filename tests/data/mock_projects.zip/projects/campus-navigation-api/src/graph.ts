export type Graph = Record<string, string[]>;

export function shortestPath(graph: Graph, start: string, goal: string): string[] {
  const queue: Array<{ node: string; path: string[] }> = [{ node: start, path: [start] }];
  const seen = new Set([start]);
  while (queue.length) {
    const { node, path } = queue.shift()!;
    if (node === goal) return path;
    for (const nbr of graph[node] || []) {
      if (!seen.has(nbr)) {
        seen.add(nbr);
        queue.push({ node: nbr, path: [...path, nbr] });
      }
    }
  }
  return [];
}
export function isReachable(graph: Graph, start: string, goal: string) { return shortestPath(graph, start, goal).length > 0; }
function shortestPathSafe(graph, start, goal){ return shortestPath(graph, start, goal).filter(x=>!closures.has(x)); }
