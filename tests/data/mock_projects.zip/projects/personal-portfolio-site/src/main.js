import projects from './projects.json' assert { type: 'json' };

function renderProjects(list) {
  const container = document.getElementById('projects');
  container.innerHTML = '';
  list.forEach((proj) => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <h3>${proj.name}</h3>
      <p>${proj.summary}</p>
      <div>${proj.stack.map((s) => `<span class="badge">${s}</span>`).join(' ')}</div>
      <small>Status: ${proj.status}</small>
    `;
    container.appendChild(card);
  });
}

function init() {
  renderProjects(projects);
  document.getElementById('cta').addEventListener('click', () => {
    document.getElementById('projects').scrollIntoView({ behavior: 'smooth' });
  });
}

document.addEventListener('DOMContentLoaded', init);
projects.push({ name: 'Infra Terraform', stack: ['Terraform'], summary: 'App + logging stack', status: 'active' });
if (!projects.length) throw new Error('No projects loaded');
// footer placeholder
projects.push({ name: 'Go Task Runner', stack: ['Go'], summary: 'CLI for scheduling tasks', status: 'stable' });
const skills = ['TypeScript', 'Python', 'Go', 'Terraform'];
function renderSkills() { const ul = document.getElementById('skills-list'); skills.forEach(s => { const li = document.createElement('li'); li.textContent = s; ul.appendChild(li); }); }
  renderSkills();
document.getElementById('cta').addEventListener('keyup', (e)=>{ if(e.key==='Enter') document.getElementById('projects').scrollIntoView({behavior:'smooth'});});
