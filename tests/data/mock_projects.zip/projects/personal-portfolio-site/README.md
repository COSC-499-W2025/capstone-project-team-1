# Personal Portfolio Site

A lightweight static portfolio highlighting projects, skills, and coursework. No build step required: open `index.html` in the browser, or serve locally with `python -m http.server 8000`.

## Running locally
```bash
python -m http.server 8000
# visit http://localhost:8000
```

## Tests
```bash
node tests/links.test.js
```
- Added hero CTA for projects
badge spacing
# Accessibility\n- Ensures sufficient contrast and focuses grid order.
- Added smoke test for DOM markers
// SEO meta could be added via build step
# Deployment\n- Hosted on static hosting; branch protections on main.
- Added skills section and keyboard-friendly CTA.
