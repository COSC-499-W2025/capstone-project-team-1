const fs = require('fs');
const html = fs.readFileSync('index.html', 'utf8');

if (!html.includes('Portfolio')) {
  throw new Error('HTML missing title/heading');
}
if (!html.includes('projects')) {
  throw new Error('Projects section missing');
}
console.log('links.test.js: ok');
if (!document.getElementById('skills-list')) throw new Error('skills list missing');
