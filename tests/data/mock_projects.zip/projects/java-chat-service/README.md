# Java Chat Service

Tiny HTTP chat service using the built-in `HttpServer`. Stores messages in memory and exposes `/health`, `/messages`, and `/send` endpoints.

## Build & Run
```bash
javac -d out $(find src/main/java -name "*.java")
java -cp out com.example.chat.ChatServer
```

## Quick Test
```bash
curl -X POST -d "author=shlok&text=hi" http://localhost:8080/send
curl http://localhost:8080/messages
```
- Added validation for empty text
- JSON endpoint returns array of author/text objects.
- Ban endpoint is stubbed; extend with in-memory list.
- Set CHAT_PORT to change listener port.
- /search?q=term returns count of matching messages.
- Messages log stored under data/ for local runs.
- /count-json returns message count in JSON format.
