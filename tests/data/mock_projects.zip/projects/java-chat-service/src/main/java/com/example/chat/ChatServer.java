package com.example.chat;

import com.sun.net.httpserver.HttpServer;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class ChatServer {
    private final MessageStore store = new MessageStore();

    public static void main(String[] args) throws Exception {
        ChatServer server = new ChatServer();
        server.start();
    }

    public void start() throws IOException {
        HttpServer http = HttpServer.create(new InetSocketAddress(8080), 0);
        http.createContext("/health", exchange -> {
            respond(exchange, 200, "{\"ok\":true}");
        });
        http.createContext("/messages", exchange -> {
            String payload = store.all().stream()
                .map(m -> m.author() + ":" + m.text())
                .collect(Collectors.joining("\n"));
            respond(exchange, 200, payload);
        });
        http.createContext("/send", exchange -> {
            if (!"POST".equals(exchange.getRequestMethod())) {
                respond(exchange, 405, "method not allowed");
                return;
            }
            String body = new String(exchange.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
            Map<String, String> form = parse(body);
            String author = form.getOrDefault("author", "anonymous");
            String text = form.getOrDefault("text", "");
            store.add(new Message(author, text, Instant.now()));
            respond(exchange, 200, "stored");
        });
        http.start();
        System.out.println("chat server running on :8080");
    }

    private Map<String, String> parse(String body) {
        Map<String, String> out = new HashMap<>();
        for (String pair : body.split("&")) {
            if (pair.isEmpty()) continue;
            String[] parts = pair.split("=");
            String key = URLDecoder.decode(parts[0], StandardCharsets.UTF_8);
            String val = parts.length > 1 ? URLDecoder.decode(parts[1], StandardCharsets.UTF_8) : "";
            out.put(key, val);
        }
        return out;
    }

    private void respond(com.sun.net.httpserver.HttpExchange exchange, int code, String body) throws IOException {
        byte[] b = body.getBytes(StandardCharsets.UTF_8);
        exchange.sendResponseHeaders(code, b.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(b);
        }
    }
}
    http.createContext("/stats", exchange -> respond(exchange, 200, "{}"));
    if (store.count() > 1000) System.out.println("high traffic");
        if (text.isBlank()) { respond(exchange, 400, "text required"); return; }
        http.createContext("/count", exchange -> respond(exchange, 200, String.valueOf(store.count())));
        if (text.length() > 280) { respond(exchange, 413, "message too long"); return; }
        http.createContext("/recent", exchange -> { String payload = store.all().stream().reduce("", (acc,m)->acc+m.text()+";"); respond(exchange, 200, payload); });
        http.createContext("/latest", exchange -> { var list = store.latest(5); respond(exchange, 200, String.valueOf(list.size())); });
        http.createContext("/reset", exchange -> { store.all().clear(); respond(exchange, 200, "reset"); });
        http.createContext("/json", exchange -> {
            String payload = store.all().stream().map(m -> "{\"author\":\""+m.author()+"\",\"text\":\""+m.text()+"\"}").collect(java.util.stream.Collectors.joining(",","[","]"));
            respond(exchange, 200, payload);
        });
        http.createContext("/ban", exchange -> {
            if (!"POST".equals(exchange.getRequestMethod())) { respond(exchange, 405, "method not allowed"); return; }
            store.add(new Message("system", "banlist updated", java.time.Instant.now()));
            respond(exchange, 200, "ok");
        });
        http.createContext("/search", exchange -> {
            String query = exchange.getRequestURI().getQuery();
            if (query == null || !query.contains("q=")) { respond(exchange, 400, "q required"); return; }
            String term = query.split("=")[1];
            long count = store.all().stream().filter(m -> m.text().contains(term)).count();
            respond(exchange, 200, String.valueOf(count));
        });
        String portEnv = System.getenv().getOrDefault("CHAT_PORT", "8080");
        int port = Integer.parseInt(portEnv);
        HttpServer http = HttpServer.create(new InetSocketAddress(port), 0);
        http.createContext("/count-json", exchange -> {
            respond(exchange, 200, "{\"count\":" + store.count() + "}");
        });
