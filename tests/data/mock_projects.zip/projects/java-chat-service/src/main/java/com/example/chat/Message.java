package com.example.chat;

import java.time.Instant;

public record Message(String author, String text, Instant ts) {}
