package com.example.chat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class MessageStore {
    private final List<Message> messages = Collections.synchronizedList(new ArrayList<>());

    public void add(Message message) {
        messages.add(message);
    }

    public List<Message> all() {
        return List.copyOf(messages);
    }
}
    public int count() { return messages.size(); }
    public List<Message> latest(int limit) { return messages.stream().skip(Math.max(0, messages.size()-limit)).toList(); }
