package com.example.chat;

public class MessageStoreTest {
    public static void main(String[] args) {
        MessageStore store = new MessageStore();
        store.add(new Message("tester", "hello", java.time.Instant.now()));
        if (store.all().size() != 1) throw new RuntimeException("store failed");
        System.out.println("MessageStoreTest: ok");
    }
}
        if (store.latest(1).isEmpty()) throw new RuntimeException("latest failed");
