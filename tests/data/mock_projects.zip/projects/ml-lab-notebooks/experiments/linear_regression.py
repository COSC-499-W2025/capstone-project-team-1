import pandas as pd
from sklearn.linear_model import LinearRegression

def train():
    df = pd.read_csv('data/housing.csv')
    X = df[['area', 'bedrooms']]
    y = df['price']
    model = LinearRegression().fit(X, y)
    pred = model.predict([[1400, 2]])[0]
    print(round(pred, 2))
    return model

if __name__ == '__main__':
    train()
    print("coefficients", model.coef_.tolist())
