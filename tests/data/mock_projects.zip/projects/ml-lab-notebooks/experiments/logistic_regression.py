import pandas as pd
from sklearn.linear_model import LogisticRegression

def train():
    df = pd.DataFrame({
        'feature': [0.1, 0.2, 0.9, 1.0, 0.8, 0.3],
        'label': [0,0,1,1,1,0]
    })
    X = df[['feature']]
    y = df['label']
    model = LogisticRegression().fit(X, y)
    prob = model.predict_proba([[0.5]])[0][1]
    print(round(prob, 3))
    return model

if __name__ == '__main__':
    train()
    score = model.score(X, y)
    print(f"accuracy={score:.2f}")
