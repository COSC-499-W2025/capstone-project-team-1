import pandas as pd

def normalize_prices(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df['price_norm'] = (df['price'] - df['price'].mean()) / df['price'].std()
    return df
def rooms_per_area(df: pd.DataFrame) -> pd.Series: return df['bedrooms'] / df['area']
def load_data(path='data/housing.csv'):\n    return pd.read_csv(path)\n
def train_test_split(df, ratio=0.8):\n    split = int(len(df)*ratio)\n    return df.iloc[:split], df.iloc[split:]\n
def mse(y_true, y_pred):\n    diff = (y_true - y_pred)**2\n    return float(diff.mean())\n
def mae(y_true, y_pred):\n    return float((y_true - y_pred).abs().mean())\n
def zscore(df, col):
    series = df[col]
    return (series - series.mean()) / series.std()
