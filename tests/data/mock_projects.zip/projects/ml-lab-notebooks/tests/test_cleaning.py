import pandas as pd
from experiments.cleaning import normalize_prices

def test_normalize_prices_adds_column():
    df = pd.DataFrame({'price': [1, 2, 3]})
    out = normalize_prices(df)
    assert 'price_norm' in out.columns
def test_rooms_per_area():\n    from experiments.cleaning import rooms_per_area\n    out = rooms_per_area(pd.DataFrame({'area':[100], 'bedrooms':[2]}))\n    assert float(out.iloc[0]) == 0.02\n
def test_load_data():\n    from experiments.cleaning import load_data\n    df = load_data()\n    assert not df.empty\n
def test_split_sizes():\n    from experiments.cleaning import train_test_split\n    train, test = train_test_split(pd.DataFrame({'x':[1,2,3,4]}), 0.5)\n    assert len(train)==2 and len(test)==2\n
def test_mae():\n    from experiments.cleaning import mae\n    import pandas as pd\n    y_true = pd.Series([1,2]); y_pred = pd.Series([1,3]);\n    assert mae(y_true, y_pred) == 0.5\n
def test_mae_handles_zero():
    from experiments.cleaning import mae
    import pandas as pd
    y_true = pd.Series([0]); y_pred = pd.Series([0]);
    assert mae(y_true, y_pred) == 0.0
def test_zscore_mean_zero():
    from experiments.cleaning import zscore
    import pandas as pd
    s = zscore(pd.DataFrame({'p':[1,2,3]}), 'p')
    assert round(float(s.mean()), 5) == 0
