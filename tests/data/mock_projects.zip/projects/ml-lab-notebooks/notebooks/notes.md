# ML Lab Notes
- Linear regression baseline
- Feature scaling checklist
- [ ] Try ridge regression
- Consider cross-validation for regression models.
