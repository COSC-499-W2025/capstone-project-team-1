# ML Lab Notebooks

Course and side-project experiments: linear regression, classification, and small utilities for dataset prep.

## Quick start
```bash
pip install -r requirements.txt
python experiments/linear_regression.py
```
- Added rooms_per_area heuristic
- Logistic regression experiment with sklearn for binary labels.
- Added z-score utility and cross-validation TODO.
- Logging coefficients for regression runs to support model inspection.
