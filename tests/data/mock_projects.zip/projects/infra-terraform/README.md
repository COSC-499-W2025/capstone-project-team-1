# Infra Terraform

Terraform configuration for a small app stack: VPC, subnets, and an app module with S3 logging bucket. Intended for study/demo environments.

## Usage
```bash
cd envs/dev
terraform init
terraform plan
```
- Add remote state bucket for prod
- Stage environment mirrors dev with separate state.
- Added tfvars examples and version pin
- Cost center tagging local added to dev env.
- Outputs include service_url, logging_bucket, cost_center for reporting.
