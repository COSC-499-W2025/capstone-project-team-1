from collections import deque

def bfs(graph, start, goal):
    visited = set([start])
    q = deque([(start, [start])])
    while q:
        node, path = q.popleft()
        if node == goal:
            return path
        for nbr in graph.get(node, []):
            if nbr not in visited:
                visited.add(nbr)
                q.append((nbr, path + [nbr]))
    return []

def dfs(graph, start, goal):
    stack = [(start, [start])]
    seen = set()
    while stack:
        node, path = stack.pop()
        if node == goal:
            return path
        if node in seen:
            continue
        seen.add(node)
        for nbr in reversed(graph.get(node, [])):
            stack.append((nbr, path + [nbr]))
    return []

def binary_search(items, target):
    lo, hi = 0, len(items) - 1
    while lo <= hi:
        mid = (lo + hi) // 2
        if items[mid] == target:
            return mid
        if items[mid] < target:
            lo = mid + 1
        else:
            hi = mid - 1
    return -1
def two_sum(nums, target):\n    seen = {}\n    for i, n in enumerate(nums):\n        if target - n in seen:\n            return (seen[target-n], i)\n        seen[n] = i\n    return (-1, -1)\n
def bounded_binary_search(items, target, lo, hi):\n    while lo <= hi:\n        mid = (lo + hi)//2\n        if items[mid] == target:\n            return mid\n        if items[mid] < target:\n            lo = mid + 1\n        else:\n            hi = mid - 1\n    return -1\n
def dijkstra(graph, start):\n    dist = {n: float('inf') for n in graph}\n    dist[start] = 0\n    visited = set()\n    while len(visited) < len(graph):\n        node = min((n for n in graph if n not in visited), key=lambda n: dist[n])\n        visited.add(node)\n        for nbr, weight in graph[node]:\n            cand = dist[node] + weight\n            if cand < dist[nbr]:\n                dist[nbr] = cand\n    return dist\n
