import argparse
import json
from .search import bfs, dfs, binary_search


def load_graph(path: str):
    graph = {}
    with open(path) as f:
        for line in f:
            if not line.strip():
                continue
            node, neighbors = line.strip().split(":")
            graph[node.strip()] = [n.strip() for n in neighbors.split(",") if n.strip()]
    return graph

def main():
    parser = argparse.ArgumentParser(description="Run classic algorithms")
    parser.add_argument("--algo", required=True, choices=["bfs", "dfs", "binary"])
    parser.add_argument("--graph")
    parser.add_argument("--sorted")
    parser.add_argument("--start")
    parser.add_argument("--goal")
    parser.add_argument("--target", type=int)
    args = parser.parse_args()

    if args.algo in {"bfs", "dfs"}:
        graph = load_graph(args.graph)
        fn = bfs if args.algo == "bfs" else dfs
        path = fn(graph, args.start, args.goal)
        print(json.dumps(path))
    else:
        items = [int(x) for x in (args.sorted or "").split(",") if x]
        print(binary_search(items, args.target))

if __name__ == "__main__":
    main()
