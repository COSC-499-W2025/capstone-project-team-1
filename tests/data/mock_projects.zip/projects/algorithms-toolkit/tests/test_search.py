from algokit.search import bfs, dfs, binary_search

graph = {"A": ["B", "C"], "B": ["D", "E"], "C": ["F"], "E": ["F"], "D": [], "F": []}


def test_bfs_path():
    assert bfs(graph, "A", "F") == ["A", "C", "F"]

def test_dfs_path():
    assert dfs(graph, "A", "E")[-1] == "E"

def test_binary_search_found():
    assert binary_search([1,2,3,4], 3) == 2

def test_binary_search_missing():
    assert binary_search([1,2,3,4], 9) == -1
def test_two_sum_found():\n    from algokit.search import two_sum\n    assert two_sum([2,7,11,15], 9) == (0,1)\n
def test_is_sorted():\n    from algokit.sorting import is_sorted\n    assert is_sorted([1,2,3])\n    assert not is_sorted([3,2,1])\n
def test_reverse_helper():\n    from algokit.sorting import reversed_list\n    assert reversed_list([1,2,3]) == [3,2,1]\n
def test_bounded_binary():\n    from algokit.search import bounded_binary_search\n    assert bounded_binary_search([1,3,5,7], 5, 0, 3) == 2\n
def test_dijkstra():\n    from algokit.search import dijkstra\n    g = {'A': [('B',1),('C',4)], 'B':[('C',2)], 'C':[]}\n    dist = dijkstra(g, 'A')\n    assert dist['C'] == 3\n
def test_rotate():\n    from algokit.sorting import rotate\n    assert rotate([1,2,3,4], 1) == [4,1,2,3]\n
