# Algorithms Toolkit

Python utilities for interview prep: search, sort, and CLI helpers with tiny datasets. Requires Python 3.9+.

## Usage
```bash
python -m algokit.cli --algo bfs --graph data/graph.txt --start A --goal F
```

## Tests
```bash
python -m pytest
```
two_sum
# CLI examples\n- BFS over sample graph\n- binary search over sorted list
--target 5
- Added Dijkstra, rotate helper, and tests.
