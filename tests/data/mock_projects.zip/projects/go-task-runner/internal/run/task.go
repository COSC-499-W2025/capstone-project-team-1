func Execute(task Task) string { cmd := exec.Command("bash", "-lc", task.Command); out, _ := cmd.CombinedOutput(); return fmt.Sprintf("%s -> %s", task.Name, string(out)) }
type RunResult struct { Name string; Output string }
type Logger interface { Println(v ...any) }
func ScheduleLogged(tasks []Task, tick func(Task) string, log Logger) []string { out := Schedule(tasks, tick); for _, line := range out { log.Println(line) }; return out }
type ResultWriter interface { Write(Result) error }
type Result struct { Task string  Output string  }
func ToResults(lines []string) []Result { out := []Result{}; for _, l := range lines { out = append(out, Result{Task: l, Output: l}) }; return out }
import "encoding/json"
import "os"

func SaveResults(results []Result, path string) error {
    b, err := json.MarshalIndent(results, "", "  ")
    if err != nil { return err }
    return os.WriteFile(path, b, 0644)
}
