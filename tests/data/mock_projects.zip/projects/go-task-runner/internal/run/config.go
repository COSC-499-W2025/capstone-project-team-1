package run

import (
    "encoding/json"
    "os"
)

type Task struct {
    Name            string `json:"name"`
    Command         string `json:"command"`
    IntervalSeconds int    `json:"interval_seconds"`
}

type TaskConfig struct {
    Tasks []Task `json:"tasks"`
}

func LoadConfig(path string) (TaskConfig, error) {
    var cfg TaskConfig
    b, err := os.ReadFile(path)
    if err != nil {
        return cfg, err
    }
    err = json.Unmarshal(b, &cfg)
    return cfg, err
}
func Validate(cfg TaskConfig) error { if len(cfg.Tasks)==0 { return fmt.Errorf("no tasks configured") }; return nil }
