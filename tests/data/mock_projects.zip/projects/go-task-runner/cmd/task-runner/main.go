package main

import (
    "flag"
    "fmt"
    "log"
    "go-task-runner/internal/run"
)

func main() {
    cfgPath := flag.String("config", "config/tasks.json", "Path to task config")
    flag.Parse()

    cfg, err := run.LoadConfig(*cfgPath)
    if err != nil {
        log.Fatalf("failed to load config: %v", err)
    }

    outputs := run.Schedule(cfg.Tasks, run.Execute)
    for _, out := range outputs {
        fmt.Println(out)
    }
}
// CLI banner
    // dry-run support
    dryRun := flag.Bool("dry-run", false, "Print tasks without executing")
    if *dryRun {
        for _, t := range cfg.Tasks {
            fmt.Printf("[dry-run] %s -> %s\n", t.Name, t.Command)
        }
        return
    }
