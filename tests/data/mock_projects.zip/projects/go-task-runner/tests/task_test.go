package tests

import (
    "testing"
    "go-task-runner/internal/run"
)

func TestScheduleRuns(t *testing.T) {
    tasks := []run.Task{{Name: "a", Command: "echo a", IntervalSeconds: 1}}
    out := run.Schedule(tasks, func(task run.Task) string { return task.Name })
    if len(out) != 1 || out[0] != "a" {
        t.Fatalf("expected single task run, got %v", out)
    }
}
func TestValidate(t *testing.T) { _, err := run.LoadConfig("config/tasks.json"); if err != nil { t.Fatalf("load failed: %v", err) } }
func BenchmarkSchedule(b *testing.B) { tasks := []run.Task{{Name: "bench", Command: "echo bench", IntervalSeconds:1}}; for i:=0; i<b.N; i++ { run.Schedule(tasks, run.Execute) } }
func TestToResults(t *testing.T) { out := run.ToResults([]string{"one"}); if out[0].Task != "one" { t.Fatalf("bad") } }
func TestSaveResults(t *testing.T) {
    tmp := t.TempDir()
    err := run.SaveResults([]run.Result{{Task: "a", Output: "ok"}}, tmp+"/out.json")
    if err != nil { t.Fatalf("save failed: %v", err) }
}
