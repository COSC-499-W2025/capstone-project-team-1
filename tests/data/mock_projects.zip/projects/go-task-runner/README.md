# Go Task Runner

CLI to run JSON-defined tasks with simple interval scheduling. Designed for small homelab workflows.

## Run
```bash
go run ./cmd/task-runner --config config/tasks.json
```

## Test
```bash
go test ./...
```
- Added validation rules
- Added Result structs for API compatibility
- Added dry-run mode and JSON result export
