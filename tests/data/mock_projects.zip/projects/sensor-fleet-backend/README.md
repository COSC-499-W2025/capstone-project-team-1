# Sensor Fleet Backend

FastAPI service for ingesting IoT sensor readings with simple in-memory storage and health checks. Python 3.10+.

## Run
```bash
pip install -r requirements.txt
uvicorn app.main:app --reload
```

## Tests
```bash
pytest
```
# Alerting note\n- Add rate limits and auth before prod
- Added uptime and calibration endpoints
- Alerts endpoint returns readings over threshold
