from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from datetime import datetime
from typing import Dict

app = FastAPI(title="Sensor Fleet")

class SensorReading(BaseModel):
    sensor_id: str
    metric: str
    value: float
    ts: datetime = Field(default_factory=datetime.utcnow)

DB: Dict[str, list[SensorReading]] = {}

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/ingest")
def ingest(reading: SensorReading):
    DB.setdefault(reading.sensor_id, []).append(reading)
    return {"stored": len(DB[reading.sensor_id])}

@app.get("/sensors/{sensor_id}")
def readings(sensor_id: str):
    if sensor_id not in DB:
        raise HTTPException(status_code=404, detail="sensor not found")
    return DB[sensor_id]
from typing import Optional\n\nclass SensorMeta(BaseModel):\n    sensor_id: str\n    location: Optional[str] = None\n
@app.get('/sensors')\ndef list_sensors():\n    return list(DB.keys())\n
@app.get('/metrics')\ndef metrics():\n    return {sid: len(reads) for sid, reads in DB.items()}\n
@app.get('/summary')\ndef summary():\n    return {sid: len(reads) for sid, reads in DB.items()}\n
@app.delete('/sensors/{sensor_id}')\ndef delete_sensor(sensor_id: str):\n    DB.pop(sensor_id, None)\n    return {deleted: sensor_id}\n
@app.get('/uptime')\ndef uptime():\n    return {'sensors': len(DB)}\n
class SensorConfig(BaseModel):\n    sensor_id: str\n    min_value: float | None = None\n    max_value: float | None = None\n
@app.post('/calibrate')\ndef calibrate(cfg: SensorConfig):\n    return {'calibrated': cfg.sensor_id}\n
@app.get('/alerts')
def alerts():
    over = {sid: [r for r in reads if r.value > 100] for sid, reads in DB.items()}
    return {k: v for k, v in over.items() if v}
