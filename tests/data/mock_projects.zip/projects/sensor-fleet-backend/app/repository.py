from datetime import datetime, timedelta
from typing import Dict, List
from .main import SensorReading

def latest_readings(db: Dict[str, List[SensorReading]], window_minutes: int = 10):
    cutoff = datetime.utcnow() - timedelta(minutes=window_minutes)
    out = {}
    for sid, readings in db.items():
        out[sid] = [r for r in readings if r.ts >= cutoff]
    return out
def sensor_average(db, sensor_id):\n    vals = [r.value for r in db.get(sensor_id, [])]\n    return sum(vals)/len(vals) if vals else 0\n
def stale_sensors(db, minutes=60):\n    from datetime import datetime, timedelta\n    cutoff = datetime.utcnow() - timedelta(minutes=minutes)\n    return [sid for sid, reads in db.items() if reads and reads[-1].ts < cutoff]\n
def clear(db): db.clear()
def export_csv(db, path):\n    import csv\n    with open(path, 'w', newline='') as f:\n        writer = csv.writer(f)\n        writer.writerow(['sensor_id','metric','value','ts'])\n        for sid, readings in db.items():\n            for r in readings:\n                writer.writerow([sid, r.metric, r.value, r.ts.isoformat()])\n
