import json
import requests

with open('data/sample_readings.json') as f:
    readings = json.load(f)

for r in readings:
    res = requests.post('http://localhost:8000/ingest', json=r, timeout=2)
    print(res.status_code, res.json())
