from app.main import health, DB, ingest, SensorReading

def test_health():
    assert health()["ok"] is True

def test_ingest_and_fetch():
    DB.clear()
    ingest(SensorReading(sensor_id="temp-01", metric="temp", value=20.0))
    assert len(DB["temp-01"]) == 1
def test_average_helper():\n    from app.repository import sensor_average\n    assert sensor_average({'a': []}, 'a') == 0\n    assert sensor_average({'a': [type('R', (), {'value':1})(), type('R', (), {'value':3})()]}, 'a') == 2\n
def test_stale_detection():\n    from datetime import datetime, timedelta\n    from app.repository import stale_sensors\n    dummy = type('R', (), {})
    old = dummy(); old.ts = datetime.utcnow() - timedelta(minutes=120)
    recent = dummy(); recent.ts = datetime.utcnow()
    assert stale_sensors({'x':[old], 'y':[recent]}, 60) == ['x']

def test_clear_db():\n    from app.repository import clear\n    clear(DB)\n    assert DB == {}\n
def test_export_csv(tmp_path):\n    from app.repository import export_csv\n    DB['demo'] = []\n    export_csv(DB, tmp_path/'out.csv')\n    assert (tmp_path/'out.csv').exists()\n
def test_calibrate():\n    from app.main import calibrate, SensorConfig\n    assert calibrate(SensorConfig(sensor_id='s'))['calibrated'] == 's'\n
